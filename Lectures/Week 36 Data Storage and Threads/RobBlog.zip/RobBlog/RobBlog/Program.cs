﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Xml;

namespace RobBlog
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlDocument d = new XmlDocument();

            d.Load("http://www.robmiles.com/journal/rss.xml");

            foreach (XmlElement post in d.DocumentElement["channel"].ChildNodes)
            {
                if (post.Name == "item")
                {
                    Console.WriteLine(
                                post["title"].FirstChild.Value.ToString());
                }
            }
        }
    }
}
