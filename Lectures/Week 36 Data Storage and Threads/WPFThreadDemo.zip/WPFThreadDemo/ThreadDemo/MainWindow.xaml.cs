﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Threading;

namespace ThreadDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private int loadProgress = 0;


        delegate void SimpleMethod();

        private void updateProgressBar()
        {
            loadProgressBar.Value = loadProgress;
        }

        private void updateProgress()
        {
            SimpleMethod barUpdate = new SimpleMethod(this.updateProgressBar);
            loadProgressBar.Dispatcher.Invoke(barUpdate);
        }

        Thread loadThread;

        private void loadMethod()
        {
            loadProgress = 0;
            while (loadProgress < 100)
            {
                loadProgress++;
                updateProgress();
                Thread.Sleep(100);
            }
        }


        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            loadThread = new Thread(new ThreadStart(loadMethod));
            loadThread.Start();
        }
    }
}
