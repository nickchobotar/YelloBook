﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading;

namespace ThreadFull
{
    class Program
    {
        static void CountToTen()
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Loop: " + i);
                System.Threading.Thread.Sleep(500);
            }
        }

        static void Main(string[] args)
        {
            ThreadStart countStart;
            countStart = new ThreadStart(CountToTen);

            for (int i = 0; i < 10000; i++)
            {
                Thread countThread;
                countThread = new Thread(countStart);
                countThread.Start();
            }
            CountToTen();
        }
    }
}
