using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SpriteFun
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        #region Game World

        Sprite cursor;
        List<Sprite> sprites = new List<Sprite>();
        Texture2D drawTexture;

        Random r = new Random(1);

        #endregion 

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            drawTexture = Content.Load<Texture2D>("WhiteDot");
            Rectangle rectangle = new Rectangle(0, 0, 5, 5);
            cursor = new Sprite(drawTexture, rectangle, Color.White);

            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            GamePadState pad = GamePad.GetState(PlayerIndex.One);

            cursor.SpriteRectangle.X += (int)(pad.ThumbSticks.Left.X * 5);
            cursor.SpriteRectangle.Y -= (int)(pad.ThumbSticks.Left.Y * 5);

            int widthChange = (int)(pad.ThumbSticks.Right.X * 5);
            int heightChange = (int)(pad.ThumbSticks.Right.Y * 5);

            cursor.SpriteRectangle.Width += widthChange;
            cursor.SpriteRectangle.Height += heightChange;

            if (pad.Buttons.A == ButtonState.Pressed)
            {
                // button a is pressed
                int red = r.Next(256);
                int green = r.Next(256);
                int blue = r.Next(256);

                Color col = Color.FromNonPremultiplied(red, green, blue, 255);

                Sprite temp = new Sprite(drawTexture, cursor.SpriteRectangle,col);
                sprites.Add(temp);
            }
            if (pad.Buttons.B == ButtonState.Pressed)
            {
                sprites.Clear();
            }
            if (pad.Buttons.X == ButtonState.Pressed)
            {
                cursor.SpriteRectangle.Width = 5;
                cursor.SpriteRectangle.Height = 5;
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            foreach (Sprite s in sprites)
            {
                s.Draw(spriteBatch);
            }

            cursor.Draw(spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
