﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace SpriteDemo
{
    class Sprite
    {
        public Texture2D SpriteTexture;
        public Rectangle SpriteRectangle;

        public Color SpriteColor;

        public Sprite(Texture2D inTexture, Rectangle inRectangle, Color inColor)
        {
            SpriteTexture = inTexture;
            SpriteRectangle = inRectangle;
            SpriteColor = inColor;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(SpriteTexture, SpriteRectangle, SpriteColor);
        }
    }
}
