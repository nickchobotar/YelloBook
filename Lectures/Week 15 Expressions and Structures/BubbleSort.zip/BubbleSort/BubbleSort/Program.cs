﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BubbleSort
{
    struct Player
    {
        public int Score;
        public string Name;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Player[] team = new Player[3];
            for (int i = 0; i < team.Length; i = i + 1)
            {
                int playerNo = i + 1;
                Console.WriteLine("Player " + playerNo);
                Console.Write("Enter Name: ");
                team[i].Name = Console.ReadLine();
                Console.Write("Enter Score: ");
                team[i].Score = int.Parse(Console.ReadLine());
            }

            bool doneSwap;

            do
            {
                doneSwap = false;
                for (int i = 0; i < team.Length - 1; i = i + 1)
                {
                    if (team[i].Score < team[i + 1].Score)
                    {
                        // wrong order - have to swap
                        Player temp = team[i];
                        team[i] = team[i + 1];
                        team[i + 1] = temp;
                        doneSwap = true;
                    }
                }
            } while (doneSwap);


            foreach (Player p in team)
            {
                Console.WriteLine("Name " + p.Name + " Score " + p.Score);
            }
        }
    }
}
